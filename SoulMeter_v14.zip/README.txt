Deadlock Soul Meter v14 (Shiv, Wraith, Holliday)
=================================================
An econ HUD that compares you to the average Eternus player of the hero you're on. It shows next to SOULS
(bottom-left):
  - DMC soul rank D..SSS: your net worth (souls + items) vs the Eternus average at this match time.
    Same as Eternus = A.   D <70%  C 70-85%  B 85-95%  A 95-110%  S 110-125%  SS 125-145%  SSS 145%+
  - AHEAD +1.2k (108%)  1,480/min   how far ahead/behind, % of Eternus, your souls/min over the last 60 s
  - You 15,200 / Eternus Wraith 15,715  @15:00   your net worth next to the Eternus average now
  - unsecured souls timer, FARM! alarm (big blinking pill + sound after 20 s without souls), SPEND reminder,
    +souls popups
It picks the hero automatically and hides on heroes it has no data for.

Eternus net worth (deadlock-api.com, ranked, Eternus average badge, last 30 days):
            6:00    12:00   15:00   20:00   30:00   40:00
  Wraith    4,184   11,389  15,715  22,912  37,751  52,449
  Shiv      3,960    9,972  13,367  19,148  32,055  45,243
  Holliday  3,965    9,679  13,074  18,826  31,950  44,526

Install: copy "Soul Meter.vpk" to Deadlock\game\citadel\addons\pak88_dir.vpk (any free number) with
Deadlock closed. Mods must be enabled (Deadlock Mod Manager does that). Uninstall: delete that file.
The rank/FARM!/spend sounds come from a separate Shiv mod; without it the meter is silent.
